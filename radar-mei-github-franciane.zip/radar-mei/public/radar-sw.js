// Do not cache private pages, company data, speech or procurement responses.
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
 if(event.request.mode!=='navigate')return;
 event.respondWith(fetch(event.request).catch(()=>new Response('<!doctype html><html lang="pt-BR"><meta name="viewport" content="width=device-width,initial-scale=1"><meta charset="utf-8"><title>Radar MEI · Sem conexão</title><body style="font:20px Arial;padding:32px;background:#f5f7f5;color:#173e3a"><h1>Conecte-se à internet</h1><p>A Maria e as consultas precisam de conexão. Nenhum resultado atualizado está disponível offline.</p><a href="/assistente">Tentar novamente</a></body></html>',{headers:{'Content-Type':'text/html; charset=utf-8'},status:503})));
});
