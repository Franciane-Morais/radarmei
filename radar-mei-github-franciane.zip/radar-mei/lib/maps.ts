/** Google Maps text search; this is not a verified address or geocoded pin. */
export function mapsSearchUrl(institution:string,city:string,uf:string){
 const query=[institution.trim(),city.trim(),uf.trim(),'Brasil'].filter(Boolean).join(', ');
 return 'https://www.google.com/maps/search/?'+new URLSearchParams({api:'1',query}).toString();
}
