import {test} from 'node:test';
import assert from 'node:assert/strict';
import {guideAnswer} from '../lib/assistant.ts';
test('não inventa habilitação nem resultado de busca',()=>{assert.match(guideAnswer('Minha empresa pode participar?').text,/não decide/);assert.match(guideAnswer('Buscar editais').text,/não realizei uma busca/)});
test('pergunta fora do escopo recebe limite explícito',()=>{assert.match(guideAnswer('Qual é a previsão do tempo?').text,/não tenho uma orientação/)});
test('encaminha documento para área própria',()=>{assert.equal(guideAnswer('12.345.678/0001-90').href,'/minha-empresa')});
test('atalhos levam a destinos existentes',()=>{for(const [q,url] of [['Localizar no mapa','/mapa'],['Meus favoritos','/editais'],['Documentos da empresa','/minha-empresa']])assert.equal(guideAnswer(q).href,url)});
