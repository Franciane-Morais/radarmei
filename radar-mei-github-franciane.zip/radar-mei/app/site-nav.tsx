 'use client';
import Link from 'next/link';
import {usePathname} from 'next/navigation';
const pages=[['/','Início'],['/editais','Editais'],['/mapa','Mapa'],['/minha-empresa','Minha empresa'],['/assistente','Assistente'],['/como-usar','Como usar']];
export default function SiteNav(){const path=usePathname();return <header className="site-header"><Link className="brand" href="/"><span className="logo">◎</span>Radar<span>MEI</span></Link><nav aria-label="Menu principal">{pages.map(([url,label])=><Link key={url} href={url} className={path===url?'current':''} aria-current={path===url?'page':undefined}>{label}</Link>)}</nav></header>}
