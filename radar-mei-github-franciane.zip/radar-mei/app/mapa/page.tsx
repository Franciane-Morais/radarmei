import MapSearch from '../map-search';
export default function Mapa(){return <div className="focused-page"><div className="page-intro"><p className="eyebrow">PERTO DE VOCÊ</p><h1>Encontre o local que procura</h1><p>Pesquise uma instituição e consulte sua localização no Google Maps.</p></div><MapSearch/></div>}
