import type { Metadata, Viewport } from 'next';
import Link from 'next/link';
import SiteNav from './site-nav';
import './globals.css';
export const metadata: Metadata = {title:'Radar MEI | Oportunidades para seu negócio',manifest:'/manifest.webmanifest',applicationName:'Maria · Radar MEI',description:'Consulte editais, localize instituições e prepare sua empresa para compras públicas.'};
export const viewport:Viewport={themeColor:'#1a5746',width:'device-width',initialScale:1};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="pt-BR"><body><a className="skip-link" href="#conteudo">Pular para o conteúdo</a><SiteNav/><main id="conteudo">{children}<div className="global-notice"><strong>Consulta auxiliar.</strong> Pode conter erros e dados desatualizados. Confirme sempre nas fontes oficiais. <Link href="/como-usar">Entenda os limites →</Link></div><footer><span>◎ Radar MEI<br/><small>Projeto de Franciane de Morais Silva</small></span><p>Ferramenta independente. Não garante habilitação em licitações.</p><a href="https://pncp.gov.br/app/editais" target="_blank" rel="noreferrer">Acessar PNCP ↗</a></footer></main></body></html>}
