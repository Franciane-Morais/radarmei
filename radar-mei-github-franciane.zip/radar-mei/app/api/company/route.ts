import {cleanCnpj,validCnpj,adaptCompany} from '../../../lib/company';
const respond=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(request:Request){
 let input;try{if(Number(request.headers.get('content-length'))>1024)return respond({error:'Entrada muito longa.'},413);input=await request.json()}catch{return respond({error:'Informe um CNPJ válido.'},400)}
 if(typeof input?.cnpj!=='string'||input.cnpj.length>30||!validCnpj(input.cnpj))return respond({error:'CNPJ inválido. Confira os caracteres e os dígitos verificadores.'},400);
 const cnpj=cleanCnpj(input.cnpj);
 // Provider support for letters has not been verified; do not mislabel a valid CNPJ as nonexistent.
 if(/[A-Z]/.test(cnpj))return respond({error:'CNPJ alfanumérico reconhecido. A consulta automática deste formato ainda não está disponível aqui. Use o link da Receita Federal para conferir o cadastro.'},422);
 try{const res=await fetch('https://brasilapi.com.br/api/cnpj/v1/'+cnpj,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(15000)});
 if(res.status===404)return respond({error:'CNPJ não encontrado nesta base. Isso não comprova inexistência ou irregularidade. Confira na Receita Federal.'},404);
 if(!res.ok)throw Error('Fonte indisponível');return respond(adaptCompany(await res.json(),cnpj));
 }catch{return respond({error:'Não foi possível consultar os dados públicos agora. Nenhuma pendência foi concluída. Consulte a Receita Federal ou tente novamente.'},502)}
}
