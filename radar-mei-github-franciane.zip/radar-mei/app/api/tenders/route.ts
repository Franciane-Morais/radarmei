const UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');
export async function GET(request: Request) {
 const input = new URL(request.url).searchParams;
 const uf = input.get('uf') || '';
 const page = Number(input.get('page') || 1);
 const days = Number(input.get('days') || 30);
 if ((uf && !UFS.includes(uf)) || !Number.isInteger(page) || page < 1 || page > 10000 || ![7,30,90].includes(days)) return Response.json({error:'Filtros inválidos.'},{status:400});
 const end = new Date(Date.now()+days*86400000);
 const date = new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(end).replaceAll('-','');
 const params = new URLSearchParams({dataFinal:date,pagina:String(page),tamanhoPagina:'50'});
 if(uf) params.set('uf',uf);
 try {
 const res = await fetch('https://pncp.gov.br/api/consulta/v1/contratacoes/proposta?'+params,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(22000)});
 if(res.status===204) return Response.json({items:[],total:0,hasMore:false,scanned:0,checkedAt:new Date().toISOString()});
 if(!res.ok) throw new Error('PNCP '+res.status);
 const data = await res.json();
 if(!Array.isArray(data.data)) throw new Error('Resposta inválida');
 const items = data.data.filter((r:any)=>r && r.numeroControlePNCP).map((r:any)=>{
 const cnpj=r.orgaoEntidade?.cnpj, year=r.anoCompra, seq=r.sequencialCompra;
 const valid=/^\d{14}$/.test(String(cnpj)) && /^\d{4}$/.test(String(year)) && /^\d+$/.test(String(seq));
 return {id:r.numeroControlePNCP,objeto:r.objetoCompra||'Objeto não informado',orgao:r.orgaoEntidade?.razaoSocial||'Órgão não informado',municipio:r.unidadeOrgao?.municipioNome||'',uf:r.unidadeOrgao?.ufSigla||'',modalidade:r.modalidadeNome||'',valor:r.valorTotalEstimado,encerramento:r.dataEncerramentoProposta,abertura:r.dataAberturaProposta,link:valid?`https://pncp.gov.br/app/editais/${cnpj}/${year}/${seq}`:'https://pncp.gov.br/app/editais'};
 });
 return Response.json({items,total:data.totalRegistros??null,hasMore:typeof data.totalPaginas==='number'?page<data.totalPaginas:data.data.length===50,scanned:data.data.length,checkedAt:new Date().toISOString()});
 }catch {return Response.json({error:'O PNCP não respondeu à consulta. Tente novamente em instantes ou acesse o portal oficial. Nenhum resultado fictício foi incluído.'},{status:502});}
}
