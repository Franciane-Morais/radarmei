 'use client';
import {useState} from 'react';
import CompanyPanel from '../company-panel';
export default function MinhaEmpresa(){const [open,setOpen]=useState(true);return <div className="focused-page"><div className="page-intro"><p className="eyebrow">ORGANIZE SUA PARTICIPAÇÃO</p><h1>Minha empresa</h1><p>Consulte o cadastro e use o roteiro de conferência dos documentos.</p></div><CompanyPanel open={open} onOpen={setOpen}/></div>}
